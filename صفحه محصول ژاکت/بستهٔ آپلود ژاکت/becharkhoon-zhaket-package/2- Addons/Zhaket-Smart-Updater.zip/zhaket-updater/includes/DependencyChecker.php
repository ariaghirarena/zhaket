<?php

namespace ZhaketUpdater;

use ZhaketUpdater\AdminNotice\AdminNotice;
use ZhaketUpdater\AdminNotice\GenerateNotice;
use ZhaketUpdater\AdminNotice\Message;
use ZhaketUpdater\AdminNotice\NoticeLocation;
use ZhaketUpdater\AdminNotice\NotificationType;
use ZhaketUpdater\HelpersClass\SingleInstance;

final class DependencyChecker
{
    use SingleInstance;
    /**
     * @var bool
     */
    private $phpHasError=true;
    /**
     * @var bool
     */
    private $ioncubeHasError=true;


    public function __construct(){
        $this->checkDependency();
    }

    /**
     * @return bool
     */
    public function ioncubeHasError()
    {
        return $this->ioncubeHasError;
    }

    /**
     * @return void
     */
    private function checkDependency(){
        $this->checkPhpVersion();
        $this->checkIonCubeStatus();
        $this->showNoticeHook();
    }

    /**
     * @return bool
     */
    public function canRunApplication()
    {
        return !$this->phpHasError && !$this->ioncubeHasError;
    }


    /**
     * @return void
     */
    private function showNoticeHook()
    {
        // On a PHP version the bundle is not made for, a newer loader would not help: only the PHP notice is shown.
        if ($this->ioncubeHasError && !$this->phpHasError){
            add_action('admin_notices',function (){
                echo (new GenerateNotice())->make($this->ionCubeErrorMessage());
            });

        }

        if ($this->phpHasError){
            add_action('admin_notices',function (){
                echo (new GenerateNotice())->make($this->phpErrorMessage());
            });
        }
    }

    /**
     * PHP versions the ionCube bundle is encoded for (encode script SECTIONS="74:14 81:14 82:14 84:15"):
     * 7.4, 8.1, 8.2 (also runs on 8.3) and 8.4 (also runs on 8.5). There is no 8.0 section.
     *
     * @var string[]
     */
    const SUPPORTED_PHP = ['7.4', '8.1', '8.2', '8.3', '8.4', '8.5'];

    /**
     * @return void
     */
    protected function checkPhpVersion(){
        $this->phpHasError = !in_array(PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION, self::SUPPORTED_PHP, true);
    }

    /**
     * Lowest ionCube loader that runs the bundle on this PHP: files for 7.4 to 8.3 are made with encoder 14,
     * files for 8.4 and 8.5 with encoder 15.
     *
     * @return string
     */
    public function requiredLoaderVersion()
    {
        return PHP_VERSION_ID >= 80400 ? '15.0' : '14.0';
    }

    /**
     * @return void
     */
    protected function checkIonCubeStatus()
    {
        if (!extension_loaded('ionCube Loader') || !function_exists('ioncube_loader_version')) return;

        if (version_compare(ioncube_loader_version(), $this->requiredLoaderVersion(), '>='))
            $this->ioncubeHasError=false;
    }


    /**
     * @return array
     */
    public function ionCubeErrorMessage() {
        /* translators: %s: lowest ionCube loader version needed on this PHP version, for example 14.0 */
        $content= esc_html(sprintf(__('we detect you do not have ionCube loader or it is too old , please call to your host service to install or update ionCube loader to version %s or higher','zhaket-updater'), $this->requiredLoaderVersion()));
        return [
            'title'=>esc_html__('Error in zhaket smart updater','zhaket-updater'),
            'title_color'=>'white',
            'content_color'=>'white',
            'bg_color'=>'#FF6437',
            'content'=>$content,
        ];
    }

    /**
     * @return array
     */
    public function phpErrorMessage(){
        /* translators: %s: the site's PHP version, for example 8.0.30 */
        $content = esc_html(sprintf(__('Zhaket updater plugin needs php version 7.4 or 8.1 to 8.5 (php 8.0 is not supported). your php version is %s. please call to your host service to change php version','zhaket-updater'), PHP_VERSION));
        return [
            'title'=>esc_html__('Error in zhaket smart updater','zhaket-updater'),
            'title_color'=>'white',
            'content_color'=>'white',
            'bg_color'=>'#FF6437',
            'content'=>$content,
        ];
    }
}